public class PhoneApp {
    public static void main(String[] args) {
        // Create a new Samsung Galaxy S6 phone
        SamsungGalaxyS6 samsungPhone = new SamsungGalaxyS6();

        // Add contacts to the Samsung phone
        samsungPhone.addContact("1", "123456789", "Nick", "Doe");
        samsungPhone.addContact("2", "987654321", "Kate", "Doe");

        // Display first and last contacts
        samsungPhone.getFirstContact();
        samsungPhone.getLastContact();

        // Send a message to the first contact
        samsungPhone.sendMessage("123456789", "Hello Nick, how are you?");

        // Get first and second messages
        samsungPhone.getFirstMessage("123456789");
        samsungPhone.getSecondMessage("123456789");

        // Make a call to the second contact
        samsungPhone.call("987654321");

        // View call history
        samsungPhone.viewHistory();

        // Create a new iPhone 12
        IPhone12 iPhone12 = new IPhone12();

        // Add contacts to the iPhone phone
        iPhone12.addContact("1", "555123456", "Alice", "Smith");
        iPhone12.addContact("2", "555987654", "Bob", "Johnson");

        // Display first and last contacts
        iPhone12.getFirstContact();
        iPhone12.getLastContact();

        // Send a message to the first contact
        iPhone12.sendMessage("555123456", "Hello Alice, how are you?");

        // Get first and second messages
        iPhone12.getFirstMessage("555123456");
        iPhone12.getSecondMessage("555123456");

        // Make a call to the second contact
        iPhone12.call("555987654");

        // View call history
        iPhone12.viewHistory();
    }
}
