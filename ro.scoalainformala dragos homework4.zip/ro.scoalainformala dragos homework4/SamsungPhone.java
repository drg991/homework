// SamsungPhone.java
class SamsungPhone extends AbstractPhone {

    public SamsungPhone() {
        this.manufacturer = "Samsung";
        this.model = "Generic Samsung Model";
        this.batteryLife = 24; // Default battery life in hours
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("Samsung Phone - Model: " + model + ", Battery Life: " + batteryLife + " hours");
    }
}
