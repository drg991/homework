// AbstractPhone.java
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractPhone implements Phone {
    protected String manufacturer;
    protected String model;
    protected String color;
    protected String material;
    protected int batteryLife; // in hours
    protected String IMEI;

    // Contact and message data structures
    protected List<Contact> contacts = new ArrayList<>();
    protected List<Message> messages = new ArrayList<>();
    protected List<String> callHistory = new ArrayList<>();

    // Abstract method to be overridden by specific models
    public abstract void displayPhoneInfo();

    public void addContact(String contactId, String phoneNumber, String firstName, String lastName) {
        contacts.add(new Contact(contactId, phoneNumber, firstName, lastName));
    }

    public void sendMessage(String phoneNumber, String message) {
        if (message.length() <= 500) {
            if (batteryLife > 0) {
                batteryLife--;
                messages.add(new Message(phoneNumber, message));
            } else {
                System.out.println("Battery too low to send a message!");
            }
        }
    }

    public void call(String phoneNumber) {
        if (batteryLife >= 2) {
            batteryLife -= 2;
            callHistory.add("Call made to: " + phoneNumber);
        } else {
            System.out.println("Battery too low to make a call!");
        }
    }

    public void viewHistory() {
        System.out.println("Call History: ");
        for (String record : callHistory) {
            System.out.println(record);
        }
    }

    public void getFirstContact() {
        if (!contacts.isEmpty()) {
            System.out.println(contacts.get(0).toString());
        }
    }

    public void getLastContact() {
        if (!contacts.isEmpty()) {
            System.out.println(contacts.get(contacts.size() - 1).toString());
        }
    }

    public void getFirstMessage(String phoneNumber) {
        for (Message message : messages) {
            if (message.getPhoneNumber().equals(phoneNumber)) {
                System.out.println("First message: " + message.getMessageContent());
                break;
            }
        }
    }

    public void getSecondMessage(String phoneNumber) {
        int count = 0;
        for (Message message : messages) {
            if (message.getPhoneNumber().equals(phoneNumber)) {
                if (++count == 2) {
                    System.out.println("Second message: " + message.getMessageContent());
                    break;
                }
            }
        }
    }
}
