// SamsungGalaxyS6.java
 class SamsungGalaxyS6 extends SamsungPhone {

    public SamsungGalaxyS6() {
        this.model = "Samsung Galaxy S6";
        this.batteryLife = 20; // 20 hours battery life for Galaxy S6
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("Samsung Galaxy S6 - Battery life: " + batteryLife + " hours");
    }
}
