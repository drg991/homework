// Phone.java
public interface Phone {
    void addContact(String contactId, String phoneNumber, String firstName, String lastName);
    void sendMessage(String phoneNumber, String message);
    void call(String phoneNumber);
    void viewHistory();
    void getFirstContact();
    void getLastContact();
    void getFirstMessage(String phoneNumber);
    void getSecondMessage(String phoneNumber);
}
