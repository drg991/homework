class SamsungGalaxyS20 extends SamsungPhone {

    public SamsungGalaxyS20() {
        this.model = "Samsung Galaxy S20";
        this.batteryLife = 30; // 30 hours battery life for Galaxy S20
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("Samsung Galaxy S20 - Battery life: " + batteryLife + " hours");
    }
}
