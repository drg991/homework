// ApplePhone.java
 class ApplePhone extends AbstractPhone {

    public ApplePhone() {
        this.manufacturer = "Apple";
        this.model = "Generic Apple Model";
        this.batteryLife = 18; // Default battery life in hours
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("Apple Phone - Model: " + model + ", Battery Life: " + batteryLife + " hours");
    }
}
