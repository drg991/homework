// Contact.java
 class Contact {
    private String contactId;
    private String phoneNumber;
    private String firstName;
    private String lastName;

    public Contact(String contactId, String phoneNumber, String firstName, String lastName) {
        this.contactId = contactId;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "Contact ID: " + contactId + ", Name: " + firstName + " " + lastName + ", Phone Number: " + phoneNumber;
    }
}
