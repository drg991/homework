// IPhone13.java
class IPhone13 extends ApplePhone {

    public IPhone13() {
        this.model = "iPhone 13";
        this.batteryLife = 25; // 25 hours battery life for iPhone 13
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("iPhone 13 - Battery life: " + batteryLife + " hours");
    }
}
