// IPhone12.java
class IPhone12 extends ApplePhone {

    public IPhone12() {
        this.model = "iPhone 12";
        this.batteryLife = 22; // 22 hours battery life for iPhone 12
    }

    @Override
    public void displayPhoneInfo() {
        System.out.println("iPhone 12 - Battery life: " + batteryLife + " hours");
    }
}
